Autor: Jean Carvalho Ortiz
A1: Executado
A2: Executado