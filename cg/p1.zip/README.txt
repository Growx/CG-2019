TRABALHO COMPUTA��O GR�FICA 2019 (P1)

Autores: Jean Carvalho Ortiz e Lucas Tegani Bassani
Programa utilizado: Visual Studio 2019

Atividades que foram realizadas:
A1 - Parcialmente, foi utilizada uma lista duplamente encadeada DLinkedList<SceneObject> pois com ela � poss�vel percorrer a lista
em ambas as dire��es (necessidade de acessar informa��o de um elemento antecessor) e tamb�m apresenta uma maior seguran�a
do que uma lista simplesmente encadeada uma vez que existe sempre dois ponteiros apontando para cada registro;

A2 - Totalmente;

A3 - Parcialmente, essa estrutura permite a adi��o de componentes com os m�todos addToDLLHead, addToDLLTail, addInMiddle, 
e remo��o de componentes com os m�todos deleteFromDLLHead(), deleteFromDLLTail();

A4 - N�o implementado;

A5 - Parcialmente;

A6 - Totalmente;

A7 - Totalmente;


*Foi criado um novo Header File com essa lista duplamente encadeada com o nome de DLinkedList.h .

